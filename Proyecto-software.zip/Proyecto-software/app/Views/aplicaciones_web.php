<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Aplicaciones Web</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('css/estilo.css') ?>">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">

        <h2>Aplicaciones Web</h2>
         <br>
        <h3>Frontend</h3>
        <p class="text-lowercase">El frontend se refiere a la parte de la aplicación web que interactúa 
            directamente con el usuario. Es lo que los usuarios ven y experimentan al navegar por un sitio web. 
            Incluye el diseño, la estructura y la interacción de la interfaz de usuario. 
            Los elementos típicos del frontend son botones, formularios, menús y gráficos. </p>
       <br>
        <h4>Tecnologías frontend</h4>
        <br>
        <ul>
            <li>HTML</li>
            <br>
            <p class="text-lowercase">(HyperText Markup Language): Es el lenguaje de marcado estándar para crear páginas web. 
                Se utiliza para estructurar el contenido en la web,
                 definiendo elementos como encabezados, párrafos, enlaces, imágenes, y otros componentes. </p>
            <br>
            <li>CSS</li>
            <br>
            <p class="text-lowercase">(Cascading Style Sheets): Es un lenguaje de estilo utilizado para describir la presentación 
                de un documento HTML. Permite aplicar estilos como colores, 
                fuentes, márgenes, y diseño general a las páginas web, mejorando así la apariencia visual. </p>
            <br>
            <li>JavaScript</li>
            <br>
            <p class="text-lowercase"> (JS): Es un lenguaje de programación que permite implementar funcionalidades complejas 
                en las páginas web. Se utiliza para hacer que las páginas sean interactivas, 
                por ejemplo, validando formularios, creando animaciones, y manipulando el contenido dinámicamente. </p>
            <br>
        </ul>
        <h3>Backend</h3>
        <br>
        <p class="text-lowercase">El backend se refiere a la parte de la aplicación web que no es visible para el usuario,
             y que se encarga de la lógica de negocio, el procesamiento de datos y la gestión de la base de datos. En el backend, 
             se manejan las operaciones que permiten
             a las aplicaciones funcionar correctamente y comunicarse con el frontend. </p>
        <br>
        <h4>Tecnologías backend</h4>
        <br>
        <ul>
            <li>Base de datos:</li>
            <br>
            <p class="text-lowercase">Las bases de datos son componentes esenciales en el desarrollo de aplicaciones web,
                 ya que permiten almacenar, organizar y gestionar datos de manera eficiente.
                 A continuación, se describen algunas de las bases de datos más utilizadas: </p>
            <br>
            <li>MySQL:</li>
            <p class="text-lowercase">Descripción: 
                MySQL es un sistema de gestión de bases de datos relacional (RDBMS) de código abierto.
                 Es conocido por su rendimiento, fiabilidad y facilidad de uso. </p>
            <p class="text-lowercase"> Características:
                Soporta el lenguaje SQL (Structured Query Language) para la gestión de datos.</p>
            <p class="text-lowercase"> Ideal para aplicaciones que requieren transacciones y consistencia de datos.</p>
            <p class="text-lowercase">Amplia comunidad y soporte, con numerosos recursos y documentación disponible. </p>
            <p class="text-lowercase"> Usos comunes: MySQL es popular en aplicaciones web, como WordPress y Drupal, y 
                es utilizado por muchas empresas para aplicaciones de comercio electrónico y gestión de contenido.</p>
            <br>
            <br>
            <li>PostgreSQL:</li>
            <p class="text-lowercase">Descripción: PostgreSQL es un sistema de gestión de bases de datos relacional y objeto, de código abierto. 
                Se destaca por su robustez y características avanzadas.   </p>
            <p class="text-lowercase">Características:
                Soporta tanto SQL como procedimientos almacenados en varios lenguajes.   </p>
            <p class="text-lowercase">Ofrece soporte para transacciones ACID (Atomicidad, Consistencia, Aislamiento, Durabilidad). </p>
            <p class="text-lowercase"> Capacidad para manejar datos no estructurados con tipos de datos como JSONB. </p>
            <p class="text-lowercase">Usos comunes: PostgreSQL es ideal para aplicaciones empresariales, sistemas de análisis
                 de datos y proyectos que requieren escalabilidad y flexibilidad.  </p>
            <br>
            <br>
            <li>MongoDB:</li>
            <p class="text-lowercase"> Descripción: MongoDB es una base de datos NoSQL orientada a documentos, 
                que almacena datos en formato JSON-like (BSON). Es altamente escalable y flexible. </p>
            <p class="text-lowercase">Características:
                Permite almacenar y consultar datos de manera no estructurada, 
                facilitando cambios en el esquema.  </p>
            <p class="text-lowercase">Soporta replicación y fragmentación, lo que permite escalar horizontalmente.  </p>
            <p class="text-lowercase">Ideal para manejar grandes volúmenes de datos y datos en tiempo real.  </p>
            <p class="text-lowercase"> Usos comunes: MongoDB es utilizado en aplicaciones que requieren alta disponibilidad y 
                escalabilidad, 
                como aplicaciones móviles, análisis de big data y sistemas de gestión de contenido. </p>
            <br>
            <li>SQLite:</li>
            <p class="text-lowercase">Descripción: SQLite es un sistema de gestión de bases de datos relacional ligero y de código
                 abierto.  A diferencia de otros RDBMS, es autónomo y se integra directamente en aplicaciones.  </p>
            <p class="text-lowercase">Características:
                No requiere un servidor para funcionar, ya que los datos se almacenan en un solo archivo.  </p>
            <p class="text-lowercase"> Ideal para aplicaciones pequeñas y medianas, así como para pruebas y desarrollo. </p>
            <p class="text-lowercase">Soporta la mayoría de las características de SQL, pero carece de ciertas funcionalidades
                 avanzadas de otros sistemas de bases de datos.</p>
            <p class="text-lowercase">Usos comunes: SQLite es común en aplicaciones móviles (como iOS y Android), 
                aplicaciones de escritorio y como base de datos embebida en software.</p>
            <br>
            <li>Servidor web:</li>
            <br>
            <p class="lh-1">Un servidor web es un software que maneja las solicitudes realizadas por los clientes
                 (generalmente navegadores web) y responde con el contenido adecuado, como páginas HTML, imágenes, 
                 scripts y otros recursos. Los servidores web juegan un papel crucial en el funcionamiento de las aplicaciones web,
                  ya que gestionan la comunicación entre el cliente y el servidor,
                 permitiendo que los usuarios accedan a contenido en línea.    </p>
            <br>
            <br>
            <li>Funciones de un Servidor Web</li>
            <br>
            <p class="text-lowercase">Manejo de Solicitudes: Recibe solicitudes HTTP/HTTPS de los navegadores y las procesa. </p>
            <p class="text-lowercase">Respuesta de Contenido: Envía el contenido solicitado de vuelta al cliente, que puede incluir HTML, CSS, JavaScript, imágenes y otros tipos de archivos. </p>
            <p class="text-lowercase">Gestión de Recursos: Administra y almacena los recursos del sitio web, asegurando que estén disponibles para su entrega. </p>
            <p class="text-lowercase">Soporte para Protocolos: Soporta varios protocolos de red, principalmente HTTP/HTTPS, y puede implementar redirecciones, autenticación y otros mecanismos de seguridad. </p>
            <p class="text-lowercase">Registro de Actividades: Registra información sobre las solicitudes y actividades del servidor, lo que es útil para el análisis y la optimización del rendimiento. </p>
            <br>
            <br>
            <li>1. Apache HTTP Server</li>
            <br>
            <p class="lh-1">Descripción: Apache es uno de los servidores web más utilizados en el mundo. 
                Es de código abierto y muy flexible,
                 con una gran cantidad de módulos que permiten extender sus funcionalidades.    </p>
                 <p class="lh-1">Características:
                 Soporta múltiples plataformas, incluyendo Unix, Linux, Windows y macOS.    </p>
                 <p class="lh-1"> Permite la configuración de virtual hosts, lo que permite alojar múltiples sitios en un solo servidor.   </p>
                 <p class="lh-1">Ofrece soporte para módulos como mod_ssl para conexiones HTTPS y mod_rewrite para URL amigables.    </p>
            <p class="text-lowercase">Usos comunes: Utilizado en una amplia gama de aplicaciones web, desde sitios personales hasta grandes sitios de comercio electrónico. </p>
            <br>
            <br>
            <li>Nginx:</li>
            <br>
            <p class="lh-1">Descripción: Nginx es un servidor web de alto rendimiento conocido por su capacidad para manejar múltiples conexiones concurrentes de manera eficiente. También puede funcionar como un proxy inverso y equilibrador de carga.    </p>
            <p class="lh-1">Características:
            Utiliza un modelo de arquitectura asíncrono que permite un uso eficiente de los recursos.    </p>
            <p class="lh-1"> Soporta HTTP/2 y WebSocket, lo que mejora la experiencia del usuario.   </p>
            <p class="lh-1">Excelente para servir contenido estático y manejar archivos multimedia.    </p>
            <p class="text-lowercase"> Usos comunes: Ideal para aplicaciones que requieren alto rendimiento, como plataformas de streaming y sitios con tráfico elevado.</p>
            <br>
            <br>
            <li>Microsoft IIS (Internet Information Services):</li>
            <br>
            <p class="lh-1">Descripción: IIS es el servidor web de Microsoft, integrado en los sistemas operativos Windows Server. Proporciona una interfaz gráfica de usuario para la gestión y configuración de servidores web  </p>
            <p class="lh-1">Características:
            Ofrece integración con otras tecnologías de Microsoft, como ASP.NET y SQL Server.  </p>
            <p class="lh-1">Soporta características avanzadas como la autenticación, la compresión de contenido y la gestión de caché.  </p>
            <p class="lh-1"> Permite la creación de aplicaciones web a través de un enfoque basado en IIS Manager. </p>
            <p class="lh-1">Usos comunes: Comúnmente utilizado en entornos corporativos y aplicaciones desarrolladas con tecnologías de Microsoft.  </p>
            <br>
            <li>Lenguajes de programación:</li>
            <br>
            <p class="lh-1">El desarrollo backend implica el uso de varios lenguajes de programación que gestionan la lógica del servidor, la base de datos y la integración con el frontend. A continuación se describen algunos de los lenguajes más comunes:    </p>
            <br>
            <li> PHP:</li>
            <br>
            <p class="lh-1"> Descripción: PHP (Hypertext Preprocessor) es un lenguaje de scripting del lado del servidor que se utiliza principalmente para desarrollar aplicaciones web dinámicas. Es uno de los lenguajes más populares en el desarrollo web.   </p>
            <p class="lh-1">aracterísticas:
            Fácil de aprender y ampliamente soportado, con una gran cantidad de recursos y documentación.    </p>
            <p class="lh-1">  Funciona bien con bases de datos como MySQL y es el lenguaje detrás de muchos sistemas de gestión de contenido (CMS), como WordPress, Joomla y Drupal.  </p>
            <p class="lh-1">Permite la integración con HTML, lo que facilita la creación de páginas web dinámicas.    </p>
            <p class="lh-1"> Usos comunes: Aplicaciones web, sitios de comercio electrónico, y sistemas de gestión de contenido.   </p>
            <br>
            <li> Python:</li>
            <br>
            <p class="lh-1">Descripción: Python es un lenguaje de programación de alto nivel, conocido por su legibilidad y simplicidad. Es popular en el desarrollo web gracias a sus frameworks.    </p>
            <p class="lh-1"> Características:
            Ofrece múltiples frameworks para el desarrollo web, como Django (que enfatiza la rapidez y la simplicidad) y Flask (un microframework ligero).   </p>
            <p class="lh-1"> Excelente para el análisis de datos, aprendizaje automático y desarrollo de APIs, lo que lo hace versátil para una variedad de aplicaciones.   </p>
            <p class="lh-1">Gran comunidad y amplia colección de bibliotecas y módulos.    </p>
            <p class="lh-1">Usos comunes: Aplicaciones web, análisis de datos, aprendizaje automático, y automatización.    </p>
            <br>
            <li>Node.js:</li>
            <br>
            <p class="lh-1">Descripción: Node.js es un entorno de ejecución de JavaScript que permite ejecutar código JavaScript en el servidor. Es conocido por su capacidad para manejar aplicaciones en tiempo real.    </p>
            <p class="lh-1"> Características:
            Utiliza un modelo de I/O no bloqueante, lo que lo hace altamente escalable y eficiente para manejar múltiples conexiones concurrentes.   </p>
            <p class="lh-1">Permite el uso de JavaScript tanto en el frontend como en el backend, facilitando el desarrollo de aplicaciones web completas.    </p>
            <p class="lh-1"> Gran ecosistema de paquetes disponibles a través de npm (Node Package Manager).   </p>
            <p class="lh-1"> Usos comunes: Aplicaciones en tiempo real, como chats, sistemas de colaboración, y APIs RESTful.   </p>
            <br>
            <li> Ruby:</li>
            <br>
            <p class="lh-1">Descripción: Ruby es un lenguaje de programación dinámico y orientado a objetos, conocido por su simplicidad y productividad. El framework más popular para Ruby es Ruby on Rails.    </p>
            <p class="lh-1"> Características:
            Fomenta un enfoque de "convención sobre configuración", lo que acelera el proceso de desarrollo.   </p>
            <p class="lh-1">Su sintaxis es sencilla y fácil de leer, lo que facilita la colaboración entre desarrolladores.    </p>
            <p class="lh-1"> Ofrece una gran cantidad de gemas (bibliotecas) que extienden su funcionalidad.   </p>
            <p class="lh-1">Usos comunes: Aplicaciones web, startups, y prototipos rápidos.    </p>
            <br>
        </ul>
        <h3>FullStack:</h3>
        <br>
        <p class="text-lowercase"> El Full Stack se refiere a un enfoque integral en el desarrollo de aplicaciones que abarca tanto el frontend como el backend. Los desarrolladores full stack son profesionales versátiles que poseen habilidades en ambas áreas, lo que les permite trabajar en todas las etapas del desarrollo de software.</p>
        <br>
        <h3>Características del Desarrollo Full Stack</h3>
        <br>
        <p class="text-lowercase">Versatilidad: Un desarrollador full stack puede trabajar en la interfaz de usuario, la lógica del servidor y la base de datos, lo que le permite tener una comprensión completa del proyecto.  </p>
        <p class="text-lowercase">Colaboración Efectiva: Al tener conocimientos en ambas áreas, pueden actuar como intermediarios entre el equipo de frontend y el de backend, facilitando la comunicación y la integración.  </p>
        <p class="text-lowercase"> Flexibilidad en el Trabajo: Pueden abordar una variedad de tareas dentro de un proyecto, lo que les permite adaptarse a diferentes roles según sea necesario. </p>
        <p class="text-lowercase">Conocimiento Amplio: Los desarrolladores full stack suelen conocer varios lenguajes de programación, frameworks, herramientas y mejores prácticas, lo que les permite tomar decisiones informadas sobre la arquitectura y diseño de la aplicación.  </p>
        <br>
        <h3>Herramientas y Tecnologías Comunes para Desarrolladores Full Stack: </h3>
        <p class="text-lowercase"> Frontend: HTML, CSS, JavaScript, frameworks como React, Angular y Vue.js. </p>
        <p class="text-lowercase">Backend: PHP, Python, Ruby, Node.js, y bases de datos como MySQL, PostgreSQL y MongoDB.  </p>
        <p class="text-lowercase">DevOps: Conocimientos sobre servidores web (Apache, Nginx), servicios en la nube (AWS, Azure) y herramientas de contenedorización (Docker).  </p>
        <p class="text-lowercase">Control de Versiones: Git y plataformas como GitHub o GitLab para la colaboración y gestión de código.  </p>
        <br>
    </div>
</body>
</html>
