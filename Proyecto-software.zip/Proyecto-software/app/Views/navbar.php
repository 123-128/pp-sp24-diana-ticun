<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="<?= base_url('home') ?>">Proyecto Software</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="<?= base_url('home') ?>">Inicio</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= base_url('proyecto-software') ?>">Proyecto de Software</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= base_url('aplicaciones-web') ?>">Aplicaciones Web</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= base_url('framework') ?>">Framework</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= base_url('creditos') ?>">Créditos</a></li>
        </ul>
    </div>
</nav>
