<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Framework</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('css/estilo.css') ?>">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h2>Framework</h2>
        <br>
        <p class="text-lowercase"> Un framework es una estructura de software que proporciona un entorno predefinido para desarrollar aplicaciones. Facilita el trabajo al ofrecer bibliotecas, herramientas y patrones reutilizables, permitiendo a los desarrolladores centrarse en la lógica de negocio en lugar de los detalles básicos de programación. Los frameworks suelen incluir soporte para manejo de datos, enrutamiento de solicitudes, plantillas y autenticación, entre otros. </p>
        <br>
        <h3>Ventajas y desventajas</h3>
        <br>
        <h3>Ventajas:</h3>
        <p class="text-lowercase">Eficiencia: Acelera el desarrollo al proporcionar funciones predefinidas y herramientas integradas.  </p>
        <p class="text-lowercase">Estandarización: Promueve prácticas de desarrollo consistentes y estándares, facilitando la colaboración.  </p>
        <p class="text-lowercase">Seguridad: Los frameworks populares suelen actualizarse regularmente para solucionar problemas de seguridad.  </p>
        <p class="text-lowercase">Comunidad: Muchos frameworks tienen comunidades grandes y activas, lo que significa acceso a soporte, tutoriales y bibliotecas adicionales.  </p>
         <br>
         <h3>Desventajas:</h3>
         <br>
         <p class="text-lowercase"> Curva de aprendizaje: Requiere tiempo para aprender las convenciones y la estructura del framework. </p>
         <p class="text-lowercase">Limitaciones: Puede imponer restricciones que dificulten la implementación de soluciones personalizadas.  </p>
         <p class="text-lowercase"> Actualizaciones constantes: Las versiones nuevas del framework pueden requerir ajustes importantes en el código. </p>
         <br>
        <h3>Frameworks Frontend más usados</h3>
        <ul>
            <li>React:</li>
            <br>
            <p class="text-lowercase"> Una biblioteca de JavaScript desarrollada por Facebook, popular por su rendimiento y modularidad. Es ideal para interfaces de usuario interactivas. </p>
            <br>
            <p class="text-lowercase"> Ventajas: Alta flexibilidad, comunidad activa, soporte para desarrolladores, y herramientas como React DevTools. Compatible con muchas bibliotecas y frameworks. </p>
            <br>
            <p class="text-lowercase">Desventajas: La curva de aprendizaje puede ser empinada para los nuevos en la programación de JavaScript. El ritmo de cambio y nuevas actualizaciones puede ser rápido.  </p>
            <br>

            <li>Angular</li>
            <br>
            <p class="text-lowercase">Un framework de JavaScript mantenido por Google. Proporciona un conjunto completo de herramientas para crear aplicaciones web de una sola página (SPA).  </p>
            <br>
            <p class="text-lowercase"> Ventajas: Funcionalidades completas, como inyección de dependencias, enrutamiento, y formularios. Soporte nativo para TypeScript y actualizaciones periódicas. </p>
            <br>
            <p class="text-lowercase">Desventajas: Puede ser más difícil de aprender debido a su complejidad y características avanzadas. La configuración puede ser tediosa.  </p>
            <br>

            <li>Vue.js</li>
            <br>
            <p class="text-lowercase">Un framework progresivo para la construcción de interfaces de usuario. Es más flexible y fácil de aprender en comparación con React y Angular.  </p>
            <br>
            <p class="text-lowercase">Ventajas: Sintaxis simple, excelente documentación, y fácil integración con otros proyectos. Es flexible y permite usar solo partes del framework.  </p>
            <br>
            <p class="text-lowercase">Desventajas: El ecosistema es menos extenso en comparación con Angular y React. La comunidad no es tan grande como la de React.  </p>
            <br>

            <li>Svelte: </li>
            <br>
            <p class="text-lowercase">Un framework que compila el código en JavaScript puro y se enfoca en la eficiencia y la experiencia del usuario.  </p>
            <br>
            <p class="text-lowercase">Ventajas: Menor peso del paquete final, mayor rendimiento y experiencia de usuario, y código más limpio y legible.  </p>
            <br>
            <p class="text-lowercase">Desventajas: Comunidad y ecosistema más pequeños en comparación con otros frameworks. El soporte de terceros es más limitado.  </p>
            <br>

        </ul>
        <h3>Frameworks Backend más usados</h3>
        <br>
        <ul>
            <li>Django (Python):</li>
            <br>
            <p class="text-lowercase">Facilita el desarrollo rápido y seguro de aplicaciones web. Viene con muchas funciones integradas, como un sistema de autenticación y un ORM.  </p>
            <br>
            <p class="text-lowercase"> Ventajas: Alta seguridad, incluye características listas para usar, y cuenta con una comunidad activa. Ideal para aplicaciones de gran escala y con muchos datos. </p>
            <br>
            <p class="text-lowercase">Desventajas: Puede ser excesivo para proyectos pequeños. La flexibilidad es limitada comparada con frameworks más ligeros.  </p>
            <br>

            <li>Spring (Java):</li>
            <br>
            <p class="text-lowercase"> Popular en el desarrollo de aplicaciones empresariales por su capacidad para manejar transacciones, seguridad y conexiones de base de datos. </p>
            <br>
            <p class="text-lowercase">Ventajas: Ideal para aplicaciones empresariales complejas, buena gestión de transacciones y seguridad robusta. Facilita la integración con otros frameworks y herramientas.  </p>
            <br>
            <p class="text-lowercase">Desventajas: Curva de aprendizaje pronunciada debido a su tamaño y complejidad. La configuración puede ser extensa.
            </p>
            <br>

            <li>Express.js (Node.js): </li>
            <br>
            <p class="text-lowercase">Un framework minimalista y flexible para aplicaciones basadas en Node.js, ideal para crear APIs y servicios web. </p>
            <br>
            <p class="text-lowercase"> Ventajas: Minimalista, rápido de aprender, y flexible para diferentes estilos de desarrollo. Compatible con una gran variedad de middleware. </p>
            <br>
            <p class="text-lowercase">Desventajas: No tiene tantas características integradas, lo que puede requerir la integración de middleware adicional. No es ideal para aplicaciones muy grandes sin una organización adecuada del código.  </p>
            <br>

            <li>Ruby on Rails:</li>
            <br>
            <p class="text-lowercase">Un framework que sigue el principio de "convención sobre configuración" para simplificar el desarrollo de aplicaciones web.</p>
            <br>
            <p class="text-lowercase"> Ventajas: Muy productivo para proyectos con plazos ajustados. Buena estructura de código, lo que facilita el mantenimiento. Comunidad activa y muchas bibliotecas de código abierto (gems). </p>
            <br>
            <p class="text-lowercase">Desventajas: El rendimiento puede ser inferior en comparación con otros frameworks, especialmente para aplicaciones de alta carga. La popularidad de Ruby ha disminuido frente a otros lenguajes.  </p>
            <br>
        </ul>
    </div>
</body>
</html>
