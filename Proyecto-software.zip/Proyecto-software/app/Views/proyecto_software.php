<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Proyecto de Software</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('css/estilo.css') ?>">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">

    <h2>Proyectos de Software:</h2>

        <p class="text-lowercase">Un proyecto de software se refiere a la planificación, desarrollo, implementación y mantenimiento de aplicaciones o sistemas computacionales 
            que cumplen con requisitos específicos de un cliente o usuario. El objetivo principal es crear un producto de software funcional, eficiente y
             que resuelva problemas concretos o mejore procesos existentes. La gestión de estos proyectos implica la coordinación de recursos humanos y tecnológicos,
              así como el cumplimiento de plazos y presupuestos</p>

    <h3>Tipos de proyectos de software:</h3>
        <p class="text-lowercase">Los proyectos de software se pueden clasificar en diversas 
            categorías según el tipo de aplicación que se desarrolla:</p>
        <ul>
            <li>Aplicaciones web:</li>
            <p class="text-lowercase">Son sistemas diseñados para funcionar en un navegador web, lo que las hace accesibles desde cualquier dispositivo con conexión a Internet. Ejemplos incluyen plataformas 
                de e-commerce, sistemas de gestión de contenidos, y aplicaciones colaborativas como Google Docs.</p>

            <li>Aplicaciones móviles</li>
            <p class="text-lowercase">Son aplicaciones desarrolladas específicamente para dispositivos móviles, como smartphones o tabletas. Estas pueden ser nativas (diseñadas para un sistema 
                operativo específico como Android o iOS) o multiplataforma (usando frameworks como Flutter o React Native).</p>

            <li>Aplicaciones para escritorio</li>
            <p class="text-lowercase">Programas que se ejecutan en computadoras de escritorio o portátiles. Pueden ser aplicaciones específicas para sistemas operativos como Windows, macOS o Linux, y abarcan 
                desde software de productividad (como Microsoft Office) hasta herramientas de diseño (como Adobe Photoshop).</p>

            <li>Sistemas embebidos</li>
            <p class="text-lowercase">Se refiere al software que controla dispositivos o máquinas que no son computadoras tradicionales, como electrodomésticos, automóviles, 
                o equipos médicos. Estos sistemas deben ser altamente eficientes y de bajo consumo de recursos.</p>

            <li>Desarrollo de videojuegos</li>
            <p class="text-lowercase">En esta categoría, el software se enfoca en la creación de juegos interactivos para diversas plataformas, incluyendo consolas, dispositivos móviles y PC. 
                El desarrollo de videojuegos involucra tanto la programación como la creación de gráficos y sonidos.</p>
                
            <li>Software de inteligencia artificial y aprendizaje automático:</li>
            <p class="text-lowercase">Estos proyectos se centran en el desarrollo de sistemas que pueden aprender y tomar decisiones automáticamente, basándose en datos. 
                Ejemplos incluyen aplicaciones de reconocimiento de voz, análisis predictivo, y asistentes virtuales.</p> 
            
            <li>Sistemas de tiempo real:</li>
            <p class="text-lowercase">Son aquellos que requieren una respuesta inmediata a ciertos eventos, como los sistemas de control industrial o software para aeronaves, 
                donde la precisión y la rapidez son cruciales.</p>

        </ul>
    <h3>Ciclo de vida del software</h3>
        <p class="text-lowercase">El ciclo de vida del software representa el proceso completo de desarrollo
             y mantenimiento de un producto de software. Las fases principales incluyen:</p>
         <ul>
         <li> Análisis de requisitos:</li>
         <p class="text-lowercase"> Consiste en recopilar y documentar las necesidades y expectativas del
             usuario o cliente, para definir lo que debe hacer el software.  </p>

         <li>Diseño:</li>
         <p class="text-lowercase">En esta etapa se establece la arquitectura del software, especificando
             los componentes, la interfaz de usuario y la interacción entre ellos.</p>

         <li>Implementación (codificación):</li>
         <p class="text-lowercase"> Es la fase de programación, donde se escriben los códigos que conforman 
            el software, utilizando lenguajes de programación adecuados.  </p>

         <li> Pruebas (testing):</li>
         <p class="text-lowercase"> Aquí se verifican la funcionalidad y calidad del software, detectando y
             corrigiendo errores para asegurar que cumple con los requisitos establecidos. </p>

         <li>Despliegue (implementación):</li>
         <p class="text-lowercase"> El software se pone en funcionamiento en un entorno de producción, 
            ya sea para el uso interno de una organización o para el público en general. </p>

         <li>Mantenimiento: </li>
         <p class="text-lowercase">Una vez desplegado, el software requiere actualizaciones y mejoras continuas para corregir errores,
             adaptarse a cambios en el entorno tecnológico o responder a nuevas necesidades.  </p>

         <li>Retiro o reemplazo:</li>
         <p class="text-lowercase">Cuando el software llega al final de su vida útil, se descontinúa o reemplaza por una versión más 
            moderna o por otro sistema. </p>








         </ul>
    </div>
</body>
</html>
