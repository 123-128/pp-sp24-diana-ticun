<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Créditos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('css/estilo.css')?>">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
    <img src="<?= base_url('imagenes/usac-logo.png') ?>" alt="Logotipo USAC" width="150"  class="imagen-izquierda">
            <img src="<?= base_url('imagenes/efpem-logo.png') ?>" alt="Efpem LOGO" width="150" aria-colspan="60" class="imagen-derecha" >
            <BR>

        <h2>Evaluación Parcial 2</h2>
        <p><strong>Carnet:</strong>202107264</p>
        <p><strong>Nombre Completo:</strong> Diana Sofia Ticun Sánchez</p>
    </div>
</body>
</html>

