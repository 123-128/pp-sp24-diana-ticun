<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('css/estilo.css') ?>">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h2 class="mt-4">Bienvenido al Proyecto de Software</h2>
        <p>Selecciona una sección del menú para obtener más información.</p>
        <a href="<?= base_url('proyecto-software') ?>" class="btn btn-primary">Ver Proyecto de Software</a>
        <a href="<?= base_url('aplicaciones-web') ?>" class="btn btn-success">Ver Aplicaciones Web</a>
        <a href="<?= base_url('framework') ?>" class="btn btn-info">Ver Framework</a>
        <a href="<?= base_url('creditos') ?>" class="btn btn-info">Ver Creditos</a>

    </div>
</body>
</html>
