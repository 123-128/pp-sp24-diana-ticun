<?php

namespace App\Controllers;

class Creditos extends BaseController
{
    public function index(): string
    {
        return view('creditos');
    }
}
