<?php

namespace App\Controllers;

class AplicacionesWeb extends BaseController
{
    public function index(): string
    {
        return view('aplicaciones_web');
    }
}
