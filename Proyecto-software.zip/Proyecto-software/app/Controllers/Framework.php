<?php

namespace App\Controllers;

class Framework extends BaseController
{
    public function index(): string
    {
        return view('framework');
    }
}
