<?php

namespace App\Controllers;

class ProyectoSoftware extends BaseController
{
    public function index(): string
    {
        return view('proyecto_software');
    }
}
