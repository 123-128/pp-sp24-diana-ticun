<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('home', 'Home::index');
$routes->get('proyecto-software', 'ProyectoSoftware::index');
$routes->get('aplicaciones-web', 'AplicacionesWeb::index');
$routes->get('framework', 'Framework::index');
$routes->get('creditos', 'Creditos::index');
